javascript: (function () {

  prompt("Press Command + C to Copy Page Title", document.title);

})();
